# 🚗 Vehicle Counter — T5.4
**SMAI Assignment 3 · IIIT Hyderabad · 2025-26**

A Streamlit web app that detects and counts vehicles from images or video using YOLOv8n (pre-trained on COCO). No custom training needed — the model already detects cars, buses, trucks, bicycles and motorcycles out of the box.

---

## What it does

**Phase 1 — Total count**  
Upload an image or short video → get a single number: *"Vehicle Counter Output: 12"*

**Phase 2 — Category-wise count**  
Toggle to Phase 2 in the sidebar → get a breakdown:
- Bicycle
- Two-Wheeler (motorbike)
- Car
- Bus
- Truck
- Others / LCVs

---

## Project structure

```
vehicle_counter/
├── app.py              # main Streamlit application
├── requirements.txt    # Python dependencies
└── README.md           # this file
```

---

## How to run locally

**Step 1 — Clone the repo**
```bash
git clone https://github.com/<your-username>/vehicle-counter.git
cd vehicle-counter
```

**Step 2 — Create a virtual environment (optional but recommended)**
```bash
python -m venv venv
source venv/bin/activate        # Mac / Linux
venv\Scripts\activate           # Windows
```

**Step 3 — Install dependencies**
```bash
pip install -r requirements.txt
```

**Step 4 — Run the app**
```bash
streamlit run app.py
```

The browser will open at `http://localhost:8501` automatically.

> On first run, `yolov8n.pt` (~6 MB) will download automatically. You need internet for this one-time step.

---

## Running on Google Colab (free T4 GPU)

```python
# In a Colab cell:
!pip install streamlit ultralytics opencv-python-headless pillow -q
!wget -q https://raw.githubusercontent.com/<your-username>/vehicle-counter/main/app.py

# Then run with localtunnel to get a public URL:
!npm install -g localtunnel -q
!streamlit run app.py &>/content/logs.txt &
!lt --port 8501
```

---

## Tech stack

| Component | Library |
|-----------|---------|
| UI | Streamlit |
| Detection | YOLOv8n (ultralytics) |
| Image processing | OpenCV, Pillow |
| Dataset | COCO (pre-trained, no extra download) |

---

## Limitations

- Auto-rickshaws, tempos and LCVs are **not** in COCO classes, so they fall under "Others/LCVs" — this is a known limitation of using a pre-trained model.
- For video, the app reports the **peak** count seen in any single frame, not a cumulative tracker.
- Night-time / low-quality footage may give lower accuracy.

---

## Team

IIIT Hyderabad — SMAI Course 2025-26  
LLMs used: Claude (code scaffolding, debugging). All analysis and evaluation done by team.

---

## License
MIT
