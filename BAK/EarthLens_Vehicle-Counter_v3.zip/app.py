import streamlit as st
import cv2
import numpy as np
from PIL import Image
import tempfile
import os
import time
from ultralytics import YOLO

# ---- page config ----
st.set_page_config(
    page_title="Vehicle Counter",
    page_icon="🚗",
    layout="wide"
)

# ---- custom css ----
st.markdown("""
<style>
    /* main background */
    .stApp {
        background-color: #0f1117;
        color: #e8e8e8;
    }

    /* title styling */
    .main-title {
        font-size: 2.4rem;
        font-weight: 700;
        color: #f5c518;
        text-align: center;
        margin-bottom: 4px;
    }
    .sub-title {
        font-size: 1rem;
        color: #aaaaaa;
        text-align: center;
        margin-bottom: 30px;
    }

    /* count box */
    .count-box {
        background: #1a1d27;
        border: 2px solid #f5c518;
        border-radius: 10px;
        padding: 18px;
        text-align: center;
        margin: 8px 0;
    }
    .count-label {
        font-size: 0.85rem;
        color: #aaaaaa;
        text-transform: uppercase;
        letter-spacing: 1px;
    }
    .count-num {
        font-size: 2.6rem;
        font-weight: 800;
        color: #f5c518;
    }

    /* category box */
    .cat-box {
        background: #1a1d27;
        border-left: 4px solid #4fc3f7;
        border-radius: 6px;
        padding: 12px 16px;
        margin: 6px 0;
        display: flex;
        justify-content: space-between;
    }
    .cat-name { color: #e8e8e8; font-size: 0.95rem; }
    .cat-val  { color: #4fc3f7; font-weight: 700; font-size: 1.1rem; }

    /* section header */
    .section-hdr {
        font-size: 1.1rem;
        font-weight: 600;
        color: #f5c518;
        border-bottom: 1px solid #333;
        padding-bottom: 6px;
        margin: 20px 0 10px 0;
    }
    div[data-testid="stButton"] > button {
        background: #f5c518;
        color: #0f1117;
        font-weight: 700;
        border: none;
        border-radius: 6px;
        width: 100%;
    }
    div[data-testid="stButton"] > button:hover {
        background: #ffd740;
        color: #0f1117;
    }
</style>
""", unsafe_allow_html=True)


# ---- load yolo model (cached so it loads only once) ----
@st.cache_resource
def load_model():
    model = YOLO("yolov8n.pt")   # downloads automatically on first run
    return model

model = load_model()

# ---- COCO class ids we care about ----
# These are COCO dataset class IDs (fixed list of 80 classes, IDs 0-79).
# They are NOT sequential vehicle numbers — just the original COCO labels.
# Full list around our range:
#   0=person, 1=bicycle, 2=car, 3=motorcycle,
#   4=airplane (skip!), 5=bus, 6=train (skip!), 7=truck, 8=boat
# We skip 4 (airplane) and 6 (train) because they are not road vehicles.

VEHICLE_CLASSES = {
    1:  "Bicycle",
    2:  "Car",
    3:  "Two-Wheeler",   # motorcycle in COCO
    5:  "Bus",
    7:  "Truck",
}

# auto-rickshaw / LCV are not in COCO so we label them Others
# any vehicle class not in dict above goes to Others

ALL_CATS = ["Bicycle", "Two-Wheeler", "Car", "Bus", "Truck", "Others/LCVs"]

# colour per category for drawing boxes
CAT_COLORS = {
    "Bicycle":      (0, 200, 255),
    "Two-Wheeler":  (0, 255, 180),
    "Car":          (50, 200, 50),
    "Bus":          (200, 100, 0),
    "Truck":        (200, 0, 100),
    "Others/LCVs":  (180, 180, 0),
}

CONF_THRESH = 0.35   # confidence threshold


def detect_vehicles(frame, phase2=False):
    """
    Run YOLOv8 on a single frame.
    Returns (annotated_frame, total_count, cat_counts)
    cat_counts is a dict only filled when phase2=True
    """
    results = model(frame, conf=CONF_THRESH, verbose=False)[0]
    cat_counts = {c: 0 for c in ALL_CATS}
    total = 0

    for box in results.boxes:
        cls_id = int(box.cls[0])

        # only count vehicle classes
        if cls_id not in VEHICLE_CLASSES:
            continue

        label = VEHICLE_CLASSES[cls_id]
        conf  = float(box.conf[0])
        x1, y1, x2, y2 = map(int, box.xyxy[0])

        total += 1
        if phase2:
            cat_counts[label] += 1

        # draw box
        color = CAT_COLORS.get(label, (255, 255, 255))
        cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)

        if phase2:
            tag = f"{label} {conf:.2f}"
        else:
            tag = f"Vehicle {conf:.2f}"

        # small filled rectangle behind text
        (tw, th), _ = cv2.getTextSize(tag, cv2.FONT_HERSHEY_SIMPLEX, 0.55, 1)
        cv2.rectangle(frame, (x1, y1 - th - 6), (x1 + tw + 4, y1), color, -1)
        cv2.putText(frame, tag, (x1 + 2, y1 - 4),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 0, 0), 1)

    return frame, total, cat_counts


def process_image(img_array, phase2):
    frame = cv2.cvtColor(img_array, cv2.COLOR_RGB2BGR)
    annotated, total, cats = detect_vehicles(frame, phase2)
    out_rgb = cv2.cvtColor(annotated, cv2.COLOR_BGR2RGB)
    return out_rgb, total, cats


def process_video(video_path, phase2, progress_bar, status_text):
    """
    Process video frame by frame.

    Two metrics returned:
    1. peak_total + peak_cats  - counts from the single BEST frame (most vehicles).
       Total always equals sum of categories because they come from the same frame.
       Old bug: categories were taken independently so Bicycle:1 + Two-Wheeler:4 +
       Car:4 + Bus:1 + Truck:2 = 12 but peak_total showed 6. Fixed now.
    2. cumulative_cats - running sum across all sampled frames (every detection
       in entire video). Useful for overall traffic composition analysis.
    """
    cap = cv2.VideoCapture(video_path)
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    fps = cap.get(cv2.CAP_PROP_FPS) or 25

    # sample ~2 frames per second to stay fast on CPU / Colab
    sample_every = max(1, int(fps / 2))

    # store (total, cats_dict, annotated_frame) for each sampled frame
    frame_results = []
    cumulative_cats = {c: 0 for c in ALL_CATS}
    f_idx = 0

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break
        f_idx += 1

        if f_idx % sample_every != 0:
            continue

        annotated, total, cats = detect_vehicles(frame.copy(), phase2)
        frame_results.append((total, cats, annotated))

        # add this frame's detections to running totals
        for c in ALL_CATS:
            cumulative_cats[c] += cats[c]

        pct = min(f_idx / max(total_frames, 1), 1.0)
        progress_bar.progress(pct)
        status_text.text(f"Processing frame {f_idx}/{total_frames}...")

    cap.release()
    progress_bar.progress(1.0)
    status_text.text("Done!")

    if not frame_results:
        return None, 0, {c: 0 for c in ALL_CATS}, {c: 0 for c in ALL_CATS}

    # pick the single frame where most vehicles were visible
    best = max(frame_results, key=lambda x: x[0])
    peak_total = best[0]
    peak_cats  = best[1]   # from same frame as peak_total - they add up correctly now
    best_annotated = best[2]

    out_rgb = cv2.cvtColor(best_annotated, cv2.COLOR_BGR2RGB)
    return out_rgb, peak_total, peak_cats, cumulative_cats



# ============================================================
#  UI
# ============================================================

st.markdown('<div class="main-title">🚗 Vehicle Counter</div>', unsafe_allow_html=True)
st.markdown('<div class="sub-title">T5.4 — SMAI Assignment 3 · IIIT Hyderabad · YOLOv8n on COCO</div>',
            unsafe_allow_html=True)

# sidebar controls
with st.sidebar:
    st.markdown("### ⚙️ Settings")
    mode = st.radio("Input type", ["Image", "Video"])
    phase = st.radio(
        "Detection mode",
        ["Phase 1 — Total count only", "Phase 2 — Categorised count"]
    )
    use_phase2 = (phase == "Phase 2 — Categorised count")
    st.markdown("---")
    st.markdown("**Model:** YOLOv8n (COCO pretrained)")
    st.markdown("**Confidence threshold:** 0.35")
    st.markdown("**Detects:** Car, Bus, Truck, Bicycle, Two-Wheeler")
    st.caption("Auto-rickshaws and LCVs are grouped under Others/LCVs since they are not in COCO classes.")

# main area
col_upload, col_result = st.columns([1, 1.2], gap="large")

with col_upload:
    st.markdown('<div class="section-hdr">📁 Upload</div>', unsafe_allow_html=True)

    if mode == "Image":
        uploaded = st.file_uploader("Choose an image", type=["jpg", "jpeg", "png"])
    else:
        uploaded = st.file_uploader("Choose a video", type=["mp4", "avi", "mov", "mkv"])
        st.caption("Tip: Use a short clip (< 30 sec) for faster processing on free hardware.")

    run_btn = st.button("▶  Run Detection")

with col_result:
    st.markdown('<div class="section-hdr">📊 Results</div>', unsafe_allow_html=True)

    if run_btn and uploaded is not None:
        if mode == "Image":
            img = Image.open(uploaded).convert("RGB")
            img_np = np.array(img)

            with st.spinner("Detecting vehicles..."):
                out_img, total, cats = process_image(img_np, use_phase2)

            st.image(out_img, caption="Annotated image", use_container_width=True)

            # Phase 1 output
            st.markdown(
                f'<div class="count-box"><div class="count-label">Vehicle Counter Output</div>'
                f'<div class="count-num">{total}</div></div>',
                unsafe_allow_html=True
            )

            # Phase 2 output
            if use_phase2:
                st.markdown('<div class="section-hdr">🔍 Category Breakdown</div>',
                            unsafe_allow_html=True)
                for cat in ALL_CATS:
                    v = cats.get(cat, 0)
                    st.markdown(
                        f'<div class="cat-box"><span class="cat-name">{cat}</span>'
                        f'<span class="cat-val">{v}</span></div>',
                        unsafe_allow_html=True
                    )
                st.markdown(
                    f'<div class="count-box"><div class="count-label">Total Vehicles</div>'
                    f'<div class="count-num">{total}</div></div>',
                    unsafe_allow_html=True
                )

        else:  # Video
            # save to temp file
            suffix = "." + uploaded.name.split(".")[-1]
            with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
                tmp.write(uploaded.read())
                tmp_path = tmp.name

            prog  = st.progress(0)
            s_txt = st.empty()

            # now returns 4 values: image, peak_total, peak_cats, cumulative_cats
            out_img, peak_total, peak_cats, cumul_cats = process_video(
                tmp_path, use_phase2, prog, s_txt
            )
            os.unlink(tmp_path)

            # show the best frame (most vehicles visible)
            if out_img is not None:
                st.image(out_img, caption="Best frame (most vehicles detected)", use_container_width=True)

            # ---- Peak frame metric ----
            st.markdown(
                f'<div class="count-box"><div class="count-label">Peak — vehicles in best single frame</div>'
                f'<div class="count-num">{peak_total}</div></div>',
                unsafe_allow_html=True
            )

            if use_phase2:
                st.markdown('<div class="section-hdr">🔍 Peak Frame — Category Breakdown</div>',
                            unsafe_allow_html=True)
                st.caption("All numbers below are from the same frame, so they add up to the peak total above.")
                for cat in ALL_CATS:
                    v = peak_cats.get(cat, 0)
                    st.markdown(
                        f'<div class="cat-box"><span class="cat-name">{cat}</span>'
                        f'<span class="cat-val">{v}</span></div>',
                        unsafe_allow_html=True
                    )
                st.markdown(
                    f'<div class="count-box"><div class="count-label">Total (Peak Frame — matches sum above)</div>'
                    f'<div class="count-num">{peak_total}</div></div>',
                    unsafe_allow_html=True
                )

                # ---- Cumulative metric ----
                cumul_total = sum(cumul_cats.values())
                st.markdown('<div class="section-hdr">📈 Cumulative — Total detections across all frames</div>',
                            unsafe_allow_html=True)
                st.caption("Same vehicle detected in multiple frames is counted multiple times. Shows overall traffic volume.")
                for cat in ALL_CATS:
                    v = cumul_cats.get(cat, 0)
                    st.markdown(
                        f'<div class="cat-box"><span class="cat-name">{cat}</span>'
                        f'<span class="cat-val">{v}</span></div>',
                        unsafe_allow_html=True
                    )
                st.markdown(
                    f'<div class="count-box"><div class="count-label">Total Cumulative Detections</div>'
                    f'<div class="count-num">{cumul_total}</div></div>',
                    unsafe_allow_html=True
                )

    elif run_btn and uploaded is None:
        st.warning("Please upload a file first!")
    else:
        st.info("Upload an image or video, then click **Run Detection**.")
