# EarthLens - Vehicle Counter (T5.4)

**SMAI Assignment 3 - IIIT Hyderabad - 2025-26**

**Team: EarthLens**
- Jayson JJ - 2025813005
- Gangothri C - 2025813004
- Padmaja Y - 2025813002

A Streamlit web app that detects and counts vehicles from images or video using YOLOv8n (pre-trained on COCO). No custom training needed - the model already detects cars, buses, trucks, bicycles and motorcycles out of the box.

---

## What it does

**Phase 1 - Total Vehicle in Image/Video**
Upload an image or short video and get a single number: "Vehicle Counter Output: 12"

**Phase 2 - Total Vehicle by Category in Image/Video**
Toggle to Phase 2 in the sidebar and get a breakdown by vehicle type:
- Bicycle
- Car
- Two-Wheelers (motorcycle)
- Bus
- Truck

---

## Detection Settings

The app provides four adjustable settings in the sidebar:

- **Confidence Threshold** (slider, default 0.35): How confident the model must be before counting a vehicle.
- **IoU Threshold/NMS** (slider, default 0.45): Controls how overlapping boxes are merged.
- **Image Size** (dropdown: 320/640/1280, default 640): Larger size gives better accuracy but runs slower.
- **Max Detections** (slider, default 100): Limits how many vehicles detected per frame.

Each setting shows a contextual tip when adjusted so you know what the value means.

---

## Project Structure

```
EarthLens_Vehicle-Counter/
├── EarthLens.py        # main Streamlit application
├── requirements.txt    # Python dependencies
└── README.md           # this file
```

---

## How to Run Locally

**Step 1 - Clone the repo**
```bash
git clone https://github.com/<your-username>/EarthLens-Vehicle-Counter.git
cd EarthLens-Vehicle-Counter
```

**Step 2 - Create a virtual environment (optional but recommended)**
```bash
python -m venv venv
source venv/bin/activate        # Mac/Linux
venv\Scripts\activate           # Windows
```

**Step 3 - Install dependencies**
```bash
pip install -r requirements.txt
```

**Step 4 - Run the app**
```bash
streamlit run EarthLens.py
```

The browser will open at `http://localhost:8501` automatically.

On first run, `yolov8n.pt` (~6 MB) will download automatically. Internet needed for this one-time step only.

---

## Running on Google Colab (free T4 GPU)

```python
# In a Colab cell:
!pip install streamlit ultralytics opencv-python-headless pillow -q
!wget -q https://raw.githubusercontent.com/<your-username>/EarthLens-Vehicle-Counter/main/EarthLens.py

# Run with localtunnel to get a public URL:
!npm install -g localtunnel -q
!streamlit run EarthLens.py &>/content/logs.txt &
!lt --port 8501
```

---

## Tech Stack

| Component | Library |
|-----------|---------|
| UI | Streamlit |
| Detection | YOLOv8n (ultralytics) |
| Image processing | OpenCV, Pillow |
| Dataset | COCO (pre-trained, no extra download) |

---

## Note on Auto-Rickshaws and LCVs

YOLOv8n is pre-trained on COCO which has 80 classes. Our code only picks 5 road vehicle classes: Bicycle, Car, Two-Wheeler, Bus, and Truck. Anything below the confidence threshold is not detected at all, and anything detected but outside our 5 classes is simply skipped. Auto-rickshaws and other LCVs like tempos and construction vehicles are not present in COCO, so the model either misses them entirely or sometimes confuses them with a car or truck. They would not automatically go into an 'Others/Auto-rickshaws/LCVs' category even if we defined one. It would just remain as zero. To properly handle such vehicles, we would need to fine-tune YOLOv8 on a custom Indian traffic dataset, but that is outside the scope of this project as it requires significant effort for both dataset creation and model fine-tuning.

---

## Limitations

- For video, the app reports the peak count seen in any single frame, not a cumulative tracker.
- Night-time or low-quality footage may give lower accuracy.
- Auto-rickshaws and LCVs are not in COCO classes so they are not counted.

---

## Acknowledgements

LLMs used: Claude (code scaffolding, debugging). All analysis and evaluation done by team members.

---

## License
MIT
