# ============================================================
#  EarthLens - Vehicle Counter
#  Team: EarthLens
#  Members:
#    Jayson JJ       - 2025813005
#    Gangothri C     - 2025813004
#    Padmaja Y       - 2025813002
#  Course: SMAI Assignment 3 - T5.4
#  Institute: IIIT Hyderabad
#  Academic Year: 2025-26
# ============================================================

import streamlit as st
import cv2
import numpy as np
from PIL import Image
import tempfile
import os
from ultralytics import YOLO

# ---- page config ----
st.set_page_config(
    page_title="EarthLens - Vehicle Counter",
    page_icon="🚗",
    layout="wide"
)

# ---- custom css ----
st.markdown("""
<style>
    .stApp {
        background-color: #0f1117;
        color: #e8e8e8;
    }
    .main-title {
        font-size: 2.4rem;
        font-weight: 700;
        color: #f5c518;
        text-align: center;
        margin-bottom: 4px;
    }
    .sub-title {
        font-size: 1rem;
        color: #ffffff;
        text-align: center;
        margin-bottom: 6px;
    }
    .team-line {
        font-size: 1rem;
        font-weight: 700;
        color: #ffffff;
        text-align: center;
        margin-bottom: 4px;
    }
    .team-name {
        font-size: 1.05rem;
        font-weight: 700;
        color: #ffffff;
        text-align: center;
        margin-bottom: 18px;
    }
    .count-box {
        background: #1a1d27;
        border: 2px solid #f5c518;
        border-radius: 10px;
        padding: 18px;
        text-align: center;
        margin: 8px 0;
    }
    .count-label {
        font-size: 0.85rem;
        color: #aaaaaa;
        text-transform: uppercase;
        letter-spacing: 1px;
    }
    .count-num {
        font-size: 2.6rem;
        font-weight: 800;
        color: #f5c518;
    }
    .cat-box {
        background: #1a1d27;
        border-left: 4px solid #4fc3f7;
        border-radius: 6px;
        padding: 12px 16px;
        margin: 6px 0;
        display: flex;
        justify-content: space-between;
    }
    .cat-name { color: #e8e8e8; font-size: 0.95rem; }
    .cat-val  { color: #4fc3f7; font-weight: 700; font-size: 1.1rem; }
    .section-hdr {
        font-size: 1.1rem;
        font-weight: 600;
        color: #f5c518;
        border-bottom: 1px solid #333;
        padding-bottom: 6px;
        margin: 20px 0 10px 0;
    }
    .tip-box {
        background: #1a1d27;
        border-left: 3px solid #f5c518;
        border-radius: 4px;
        padding: 8px 12px;
        font-size: 0.82rem;
        color: #cccccc;
        margin-top: 4px;
        margin-bottom: 10px;
    }
    div[data-testid="stButton"] > button {
        background: #f5c518;
        color: #0f1117;
        font-weight: 700;
        border: none;
        border-radius: 6px;
        width: 100%;
    }
    div[data-testid="stButton"] > button:hover {
        background: #ffd740;
        color: #0f1117;
    }
</style>
""", unsafe_allow_html=True)


# ---- load yolo model (cached so it loads only once) ----
@st.cache_resource
def load_model():
    # yolov8n.pt will auto-download on first run (about 6 MB)
    m = YOLO("yolov8n.pt")
    return m

model = load_model()


# ============================================================
#  COCO CLASS MAPPING - EarthLens Vehicle Counter
#  Source: COCO dataset has 80 classes total (IDs 0 to 79)
#  We only use 5 road vehicle classes listed below.
#
#  COCO ID | COCO Class Name | EarthLens Class
#  --------|-----------------|---------------------------
#     0    | Person          | SKIP - not a vehicle
#     1    | Bicycle         | BICYCLE
#     2    | Car             | CAR
#     3    | Motorcycle      | TWO-WHEELERS
#     4    | Airplane        | SKIP - not a road vehicle
#     5    | Bus             | BUS
#     6    | Train           | SKIP - not a road vehicle
#     7    | Truck           | TRUCK
#     8    | Boat            | SKIP - not a road vehicle
#
#  Only 5 classes on GUI: BICYCLE, CAR, TWO-WHEELERS, BUS, TRUCK
#
#  Note on Auto-Rickshaws and LCVs:
#  YOLOv8n is pre-trained on COCO which has 80 classes. Our code only
#  picks 5 road vehicle classes: Bicycle, Car, Two-Wheeler, Bus, and Truck.
#  Anything below the confidence threshold is not detected at all, and
#  anything detected but outside our 5 classes is simply skipped.
#  Auto-rickshaws and other LCVs like tempos and construction vehicles are
#  not present in COCO, so the model either misses them entirely or sometimes
#  confuses them with a car or truck. They would not automatically go into an
#  'Others/Auto-rickshaws/LCVs' category even if we defined one. It would
#  just remain as zero. To properly handle such vehicles, we would need to
#  fine-tune YOLOv8 on a custom Indian traffic dataset, but that is outside
#  the scope of this project as it requires significant effort for both
#  dataset creation and model fine-tuning.
# ============================================================

# maps COCO class id to our display label
VEHICLE_CLASSES = {
    1: "Bicycle",
    2: "Car",
    3: "Two-Wheelers",   # COCO calls it "motorcycle"
    5: "Bus",
    7: "Truck",
    # IDs 0,4,6,8 are skipped on purpose - person, airplane, train, boat
}

# category list for GUI - Others/LCVs removed as it would always be zero
ALL_CATS = ["Bicycle", "Car", "Two-Wheelers", "Bus", "Truck"]

# bounding box colors per category (BGR format for OpenCV)
CAT_COLORS = {
    "Bicycle":      (0, 200, 255),
    "Car":          (50, 200, 50),
    "Two-Wheelers": (0, 255, 180),
    "Bus":          (200, 100, 0),
    "Truck":        (200, 0, 100),
}


# ============================================================
#  DETECTION FUNCTIONS
# ============================================================

def detect_vehicles(frame, phase2, conf_thresh, iou_thresh, imgsz, max_det):
    """
    Run YOLOv8n on one frame with user-defined settings.
    Returns annotated frame, total count, and per-category counts.
    cat_counts is only filled when phase2 is True.
    """
    results = model(
        frame,
        conf=conf_thresh,
        iou=iou_thresh,
        imgsz=imgsz,
        max_det=max_det,
        verbose=False
    )[0]

    cat_counts = {c: 0 for c in ALL_CATS}
    total = 0

    for box in results.boxes:
        cls_id = int(box.cls[0])

        # skip anything not in our 5 vehicle classes
        if cls_id not in VEHICLE_CLASSES:
            continue

        label = VEHICLE_CLASSES[cls_id]
        conf  = float(box.conf[0])
        x1, y1, x2, y2 = map(int, box.xyxy[0])

        total += 1
        if phase2:
            cat_counts[label] += 1

        color = CAT_COLORS.get(label, (255, 255, 255))
        cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)

        # label shown on bounding box
        tag = f"{label} {conf:.2f}" if phase2 else f"Vehicle {conf:.2f}"

        (tw, th), _ = cv2.getTextSize(tag, cv2.FONT_HERSHEY_SIMPLEX, 0.55, 1)
        cv2.rectangle(frame, (x1, y1 - th - 6), (x1 + tw + 4, y1), color, -1)
        cv2.putText(frame, tag, (x1 + 2, y1 - 4),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 0, 0), 1)

    return frame, total, cat_counts


def process_image(img_array, phase2, conf_thresh, iou_thresh, imgsz, max_det):
    frame = cv2.cvtColor(img_array, cv2.COLOR_RGB2BGR)
    annotated, total, cats = detect_vehicles(
        frame, phase2, conf_thresh, iou_thresh, imgsz, max_det
    )
    out_rgb = cv2.cvtColor(annotated, cv2.COLOR_BGR2RGB)
    return out_rgb, total, cats


def process_video(video_path, phase2, conf_thresh, iou_thresh, imgsz, max_det, progress_bar, status_text):
    """
    Process video frame by frame.

    Two metrics returned:
    1. peak_total + peak_cats - from the single best frame (most vehicles visible).
       Total always equals sum of categories since they come from the same frame.
    2. cumulative_cats - running sum across all sampled frames.
       Same vehicle is counted each frame it appears - shows overall traffic volume.
    """
    cap = cv2.VideoCapture(video_path)
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    fps = cap.get(cv2.CAP_PROP_FPS) or 25

    # sample about 2 frames per second to keep processing fast on CPU/Colab
    sample_every = max(1, int(fps / 2))

    frame_results = []
    cumulative_cats = {c: 0 for c in ALL_CATS}
    f_idx = 0

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break
        f_idx += 1

        if f_idx % sample_every != 0:
            continue

        annotated, total, cats = detect_vehicles(
            frame.copy(), phase2, conf_thresh, iou_thresh, imgsz, max_det
        )
        frame_results.append((total, cats, annotated))

        # add this frame counts to running totals
        for c in ALL_CATS:
            cumulative_cats[c] += cats[c]

        pct = min(f_idx / max(total_frames, 1), 1.0)
        progress_bar.progress(pct)
        status_text.text(f"Processing frame {f_idx}/{total_frames}...")

    cap.release()
    progress_bar.progress(1.0)
    status_text.text("Done!")

    if not frame_results:
        return None, 0, {c: 0 for c in ALL_CATS}, {c: 0 for c in ALL_CATS}

    # pick the frame with most vehicles visible
    best = max(frame_results, key=lambda x: x[0])
    peak_total = best[0]
    peak_cats  = best[1]   # same frame as peak_total so they add up correctly
    best_frame = best[2]

    out_rgb = cv2.cvtColor(best_frame, cv2.COLOR_BGR2RGB)
    return out_rgb, peak_total, peak_cats, cumulative_cats


# ============================================================
#  HELPER FUNCTIONS - Contextual tips for detection settings
# ============================================================

def conf_tip(val):
    if val <= 0.20:
        return f"Conf {val}: Very low - detects almost everything including many false positives. Use for testing only."
    elif val <= 0.30:
        return f"Conf {val}: Low - more detections but expect some wrong boxes mixed in."
    elif val <= 0.40:
        return f"Conf {val}: Medium - good balance between detections and accuracy. Commonly used in practice."
    elif val <= 0.55:
        return f"Conf {val}: Medium-high - fewer detections but more reliable results overall."
    elif val <= 0.70:
        return f"Conf {val}: High - only very confident detections shown. May miss some vehicles."
    else:
        return f"Conf {val}: Very high - extremely strict. Only obvious vehicles detected. Expect many misses."


def iou_tip(val):
    if val <= 0.25:
        return f"IoU {val}: Very strict NMS - overlapping boxes removed aggressively. Good for well-separated vehicles."
    elif val <= 0.40:
        return f"IoU {val}: Strict - reduces duplicate boxes well. Recommended for normal traffic scenes."
    elif val <= 0.55:
        return f"IoU {val}: Default range - balanced NMS. Works well in most traffic scenarios."
    elif val <= 0.70:
        return f"IoU {val}: Lenient - more boxes retained. Useful when vehicles are tightly packed together."
    else:
        return f"IoU {val}: Very lenient - many overlapping boxes kept. Risk of counting same vehicle twice."


def imgsz_tip(val):
    tips = {
        320: "Size 320: Fastest inference. Good for quick testing. May miss small or distant vehicles.",
        640: "Size 640: Default and recommended. Best balance of speed and accuracy for most videos.",
        1280: "Size 1280: Highest accuracy. Detects small vehicles better. Slower and needs more RAM."
    }
    return tips.get(val, f"Image size: {val}")


def maxdet_tip(val):
    if val <= 30:
        return f"Max {val}: Low cap. Fine for light traffic. Will miss vehicles if the scene is very busy."
    elif val <= 80:
        return f"Max {val}: Suitable for normal road traffic with moderate vehicle density."
    elif val <= 150:
        return f"Max {val}: Good for busy intersections or highway footage with many vehicles."
    else:
        return f"Max {val}: High cap. Handles very dense traffic scenes well. Slightly slower."


# ============================================================
#  UI - HEADER
#  Instruction 7: emojis around title - 3 left, 2 right
#  (auto-rickshaw removed as per team request)
# ============================================================

st.markdown(
    '<div class="main-title">🚲 🚗 🛵 &nbsp; Vehicle Counter &nbsp; 🚌 🚛</div>',
    unsafe_allow_html=True
)

# Instruction 4 and 8: subtitle with hyphen instead of em dash, pure white color
st.markdown(
    '<div class="sub-title">T5.4 SMAI Assignment 3 - IIIT Hyderabad - YOLOv8n on COCO</div>',
    unsafe_allow_html=True
)

# Instruction 4: team member names and roll numbers in white, matching screenshot layout
st.markdown(
    '<div class="team-line">JAYSON JJ &nbsp;&nbsp; 2025813005</div>',
    unsafe_allow_html=True
)
st.markdown(
    '<div class="team-line">GANGOTHRI C : 2025813004 &nbsp;&nbsp; | &nbsp;&nbsp; PADMAJA Y : 2025813002</div>',
    unsafe_allow_html=True
)
st.markdown(
    '<div class="team-name">EarthLens</div>',
    unsafe_allow_html=True
)


# ============================================================
#  UI - SIDEBAR
# ============================================================

with st.sidebar:

    # Instruction 3a and 3b: Info/Intro expandable section
    with st.expander("Info - About this Project", expanded=False):
        st.markdown("""
**EarthLens - Vehicle Counter** is a project made as part of SMAI Assignment 3 at IIIT Hyderabad.
The app uses YOLOv8n (a pre-trained deep learning model) to detect and count vehicles from images or videos uploaded by the user.
No custom training was done - we are using the model as it is, already trained on the COCO dataset.

---

**Phase 1: Total Vehicle in Image/Video**

Upload any image or video and the app will detect all vehicles and show one single number as output.
Example output: "Total Vehicles Detected: 12". This mode is simple and fast.

**Phase 2: Total Vehicle by Category in Image/Video**

Same as Phase 1 but also shows a breakdown by vehicle type.
Categories detected: Bicycle, Car, Two-Wheelers, Bus, Truck.
Useful for understanding what type of vehicles are present in the footage.

---

**Detection Settings**

Four settings can be adjusted to control how the model detects vehicles:
- Confidence Threshold: how sure the model must be before it counts a vehicle.
- IoU Threshold: controls how overlapping boxes are handled during Non-Maximum Suppression.
- Image Size: larger size gives better accuracy but runs slower.
- Max Detections: limits how many vehicles can be detected per frame.

---

**Important Note on Auto-Rickshaws and LCVs:**

YOLOv8n is pre-trained on COCO which has 80 classes. Our code only picks 5 road vehicle classes: Bicycle, Car, Two-Wheeler, Bus, and Truck. Anything below the confidence threshold is not detected at all, and anything detected but outside our 5 classes is simply skipped. Auto-rickshaws and other LCVs like tempos and construction vehicles are not present in COCO, so the model either misses them entirely or sometimes confuses them with a car or truck. They would not automatically go into an 'Others/Auto-rickshaws/LCVs' category even if we defined one. It would just remain as zero. To properly handle such vehicles, we would need to fine-tune YOLOv8 on a custom Indian traffic dataset, but that is outside the scope of this project as it requires significant effort for both dataset creation and model fine-tuning.
        """)

    st.markdown("---")

    st.markdown("### Input")
    mode = st.radio("Input type", ["Image", "Video"])

    # Instruction 2: updated phase names
    phase = st.radio(
        "Detection mode",
        [
            "Phase 1: Total Vehicle in Image/Video",
            "Phase 2: Total Vehicle by Category in Image/Video"
        ]
    )
    use_phase2 = ("Phase 2" in phase)

    st.markdown("---")

    # Instruction 6: four detection settings with contextual tips
    st.markdown("### Detection Settings")

    conf_val = st.slider(
        "Confidence Threshold",
        min_value=0.10, max_value=0.90, value=0.35, step=0.05
    )
    st.markdown(f'<div class="tip-box">💡 {conf_tip(conf_val)}</div>', unsafe_allow_html=True)

    iou_val = st.slider(
        "IoU Threshold (NMS)",
        min_value=0.10, max_value=0.90, value=0.45, step=0.05
    )
    st.markdown(f'<div class="tip-box">💡 {iou_tip(iou_val)}</div>', unsafe_allow_html=True)

    imgsz_val = st.selectbox("Image Size (imgsz)", options=[320, 640, 1280], index=1)
    st.markdown(f'<div class="tip-box">💡 {imgsz_tip(imgsz_val)}</div>', unsafe_allow_html=True)

    maxdet_val = st.slider(
        "Max Detections per Frame",
        min_value=10, max_value=300, value=100, step=10
    )
    st.markdown(f'<div class="tip-box">💡 {maxdet_tip(maxdet_val)}</div>', unsafe_allow_html=True)

    st.markdown("---")
    st.markdown("**Model:** YOLOv8n (COCO pretrained)")
    st.markdown("**Detects:** Bicycle, Car, Two-Wheelers, Bus, Truck")


# ============================================================
#  UI - MAIN AREA
# ============================================================

col_upload, col_result = st.columns([1, 1.2], gap="large")

with col_upload:
    st.markdown('<div class="section-hdr">Upload</div>', unsafe_allow_html=True)

    if mode == "Image":
        uploaded = st.file_uploader("Choose an image", type=["jpg", "jpeg", "png"])
    else:
        uploaded = st.file_uploader("Choose a video", type=["mp4", "avi", "mov", "mkv"])
        st.caption("Tip: Use a short clip (less than 30 sec) for faster processing on free hardware.")

    run_btn = st.button("Run Detection")

with col_result:
    st.markdown('<div class="section-hdr">Results</div>', unsafe_allow_html=True)

    if run_btn and uploaded is not None:

        if mode == "Image":
            img = Image.open(uploaded).convert("RGB")
            img_np = np.array(img)

            with st.spinner("Detecting vehicles..."):
                out_img, total, cats = process_image(
                    img_np, use_phase2, conf_val, iou_val, imgsz_val, maxdet_val
                )

            st.image(out_img, caption="Annotated image", use_container_width=True)

            st.markdown(
                f'<div class="count-box"><div class="count-label">Vehicle Counter Output</div>'
                f'<div class="count-num">{total}</div></div>',
                unsafe_allow_html=True
            )

            if use_phase2:
                st.markdown(
                    '<div class="section-hdr">Category Breakdown</div>',
                    unsafe_allow_html=True
                )
                for cat in ALL_CATS:
                    v = cats.get(cat, 0)
                    st.markdown(
                        f'<div class="cat-box"><span class="cat-name">{cat}</span>'
                        f'<span class="cat-val">{v}</span></div>',
                        unsafe_allow_html=True
                    )
                st.markdown(
                    f'<div class="count-box"><div class="count-label">Total Vehicles</div>'
                    f'<div class="count-num">{total}</div></div>',
                    unsafe_allow_html=True
                )

        else:  # Video
            suffix = "." + uploaded.name.split(".")[-1]
            with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
                tmp.write(uploaded.read())
                tmp_path = tmp.name

            prog  = st.progress(0)
            s_txt = st.empty()

            out_img, peak_total, peak_cats, cumul_cats = process_video(
                tmp_path, use_phase2, conf_val, iou_val, imgsz_val, maxdet_val, prog, s_txt
            )
            os.unlink(tmp_path)

            if out_img is not None:
                st.image(out_img, caption="Best frame - most vehicles detected", use_container_width=True)

            st.markdown(
                f'<div class="count-box"><div class="count-label">Peak - Vehicles in Best Single Frame</div>'
                f'<div class="count-num">{peak_total}</div></div>',
                unsafe_allow_html=True
            )

            if use_phase2:
                st.markdown(
                    '<div class="section-hdr">Peak Frame - Category Breakdown</div>',
                    unsafe_allow_html=True
                )
                st.caption("All numbers below are from the same frame, so they add up to the peak total above.")
                for cat in ALL_CATS:
                    v = peak_cats.get(cat, 0)
                    st.markdown(
                        f'<div class="cat-box"><span class="cat-name">{cat}</span>'
                        f'<span class="cat-val">{v}</span></div>',
                        unsafe_allow_html=True
                    )
                st.markdown(
                    f'<div class="count-box"><div class="count-label">Total - Peak Frame</div>'
                    f'<div class="count-num">{peak_total}</div></div>',
                    unsafe_allow_html=True
                )

                cumul_total = sum(cumul_cats.values())
                st.markdown(
                    '<div class="section-hdr">Cumulative - Total Detections Across All Frames</div>',
                    unsafe_allow_html=True
                )
                st.caption("Same vehicle is counted each frame it appears. Shows overall traffic volume in the full video.")
                for cat in ALL_CATS:
                    v = cumul_cats.get(cat, 0)
                    st.markdown(
                        f'<div class="cat-box"><span class="cat-name">{cat}</span>'
                        f'<span class="cat-val">{v}</span></div>',
                        unsafe_allow_html=True
                    )
                st.markdown(
                    f'<div class="count-box"><div class="count-label">Total Cumulative Detections</div>'
                    f'<div class="count-num">{cumul_total}</div></div>',
                    unsafe_allow_html=True
                )

    elif run_btn and uploaded is None:
        st.warning("Please upload a file first!")
    else:
        st.info("Upload an image or video, then click Run Detection.")
